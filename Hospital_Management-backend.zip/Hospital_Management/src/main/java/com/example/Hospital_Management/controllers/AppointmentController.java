package com.example.Hospital_Management.controllers;

import com.example.Hospital_Management.entity.Appointment;
import com.example.Hospital_Management.service.AppointmentService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/appointments")
@CrossOrigin(origins = "*")
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @PostMapping
    public Appointment bookAppointment(@RequestParam Long doctorId,
            @RequestParam Long patientId,
            @RequestParam String dateTime) {

        LocalDateTime appointmentDate = LocalDateTime.parse(dateTime);

        return appointmentService.bookAppointment(
                doctorId,
                patientId,
                appointmentDate);
    }

    @GetMapping
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }

    @PutMapping("/{id}/status")
    public Appointment updateAppointmentStatus(@PathVariable Long id, @RequestParam String status) {
        return appointmentService.updateStatus(id, status);
    }
}