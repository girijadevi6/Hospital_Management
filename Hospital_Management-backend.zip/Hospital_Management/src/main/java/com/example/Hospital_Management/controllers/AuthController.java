package com.example.Hospital_Management.controllers;

import com.example.Hospital_Management.dto.LoginRequest;
import com.example.Hospital_Management.security.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.example.Hospital_Management.dto.RegisterRequest;
import com.example.Hospital_Management.entity.AppUser;
import com.example.Hospital_Management.entity.Doctor;
import com.example.Hospital_Management.entity.Patient;
import com.example.Hospital_Management.repository.DoctorRepository;
import com.example.Hospital_Management.repository.PatientRepository;
import com.example.Hospital_Management.repository.UserRepository;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;

    public AuthController(AuthenticationManager authenticationManager,
            JwtUtil jwtUtil,
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            DoctorRepository doctorRepository,
            PatientRepository patientRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
    }

    // 1️⃣ Login endpoint
    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {

        // Authenticate user using AuthenticationManager
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword() // raw password
                ));

        return jwtUtil.generateToken(
                authentication.getName(),
                authentication.getAuthorities()
                        .iterator()
                        .next()
                        .getAuthority());
    }

    // 1.5️⃣ Register endpoint
    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return "Username already exists";
        }

        AppUser newUser = new AppUser();
        newUser.setUsername(request.getUsername());
        newUser.setPassword(passwordEncoder.encode(request.getPassword()));

        // Ensure role starts with ROLE_
        String role = request.getRole() != null ? request.getRole() : "ROLE_PATIENT";
        if (!role.startsWith("ROLE_")) {
            role = "ROLE_" + role;
        }
        newUser.setRole(role);

        AppUser savedUser = userRepository.save(newUser);

        // Create corresponding entity so appointments work
        if (role.equals("ROLE_DOCTOR")) {
            Doctor newDoctor = new Doctor();
            newDoctor.setName(request.getUsername()); // Fallback name
            newDoctor.setEmail(request.getUsername() + "@hospital.com");
            newDoctor.setSpecialization("General Provider");
            doctorRepository.save(newDoctor);
        } else if (role.equals("ROLE_PATIENT")) {
            Patient newPatient = new Patient();
            newPatient.setName(request.getUsername()); // Fallback name
            newPatient.setEmail(request.getUsername() + "@patient.com");
            patientRepository.save(newPatient);
        }

        return "User registered successfully";
    }

    // 2️⃣ Optional: generate encoded password for DB
    @GetMapping("/encode")
    public String encode() {
        return new BCryptPasswordEncoder().encode("1234");
    }
}