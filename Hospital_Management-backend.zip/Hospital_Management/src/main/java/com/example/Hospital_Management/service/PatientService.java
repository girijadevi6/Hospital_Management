package com.example.Hospital_Management.service;


import com.example.Hospital_Management.entity.Patient;
import java.util.List;

public interface PatientService {

    Patient savePatient(Patient patient);

    List<Patient> getAllPatients();

    Patient getPatientById(Long id);
}