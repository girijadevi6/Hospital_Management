package com.example.Hospital_Management.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Hospital_Management.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
}
