package com.example.Hospital_Management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Hospital_Management.entity.Appointment;
import com.example.Hospital_Management.entity.Doctor;

import java.time.LocalDateTime;

public interface AppointmentRepository 
        extends JpaRepository<Appointment, Long> {

    boolean existsByDoctorAndAppointmentDate(
            Doctor doctor, LocalDateTime appointmentDate);
}