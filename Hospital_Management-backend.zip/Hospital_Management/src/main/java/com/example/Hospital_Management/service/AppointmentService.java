package com.example.Hospital_Management.service;

import com.example.Hospital_Management.entity.Appointment;
import java.time.LocalDateTime;
import java.util.List;

public interface AppointmentService {

    Appointment bookAppointment(Long doctorId,
            Long patientId,
            LocalDateTime appointmentDate);

    List<Appointment> getAllAppointments();

    Appointment updateStatus(Long id, String status);
}